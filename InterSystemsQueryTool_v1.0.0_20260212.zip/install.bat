@echo off
chcp 65001 >nul
echo ==========================================
echo InterSystems Query Tool - 安装程序
echo ==========================================
echo.

echo 检查 Python 环境...
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.8 或更高版本
    pause
    exit /b 1
)

echo Python 环境正常
echo.

echo 安装依赖包...
pip install -r requirements.txt --trusted-host pypi.org --trusted-host files.pythonhosted.org
if errorlevel 1 (
    echo [警告] 依赖安装可能遇到问题，请检查网络连接
    pause
)

echo.
echo ==========================================
echo 安装完成！
echo ==========================================
echo.
echo 请编辑 config.json 配置数据库连接信息
echo 然后运行 start.bat 启动程序
echo.
pause

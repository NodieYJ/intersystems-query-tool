@echo off
chcp 65001 >nul
echo 正在启动 InterSystems Query Tool...
echo.
python desktop_app.py
pause

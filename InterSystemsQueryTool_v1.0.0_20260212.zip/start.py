#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
InterSystems Query Tool 启动器
"""
import sys
sys.path.insert(0, ".")
from desktop_app import main
if __name__ == "__main__":
    main()

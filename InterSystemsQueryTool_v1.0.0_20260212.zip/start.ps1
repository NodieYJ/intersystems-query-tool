# InterSystems Query Tool 启动脚本
Write-Host "正在启动 InterSystems Query Tool..." -ForegroundColor Green
python desktop_app.py
